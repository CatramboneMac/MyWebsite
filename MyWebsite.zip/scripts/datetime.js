var DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August",
"September", "October", "November", "December"];

var d = new Date();
var intervalD = setInterval(d, 10);
var datetime = "";

var day = DAYS[d.getDay()];
var month = MONTHS[d.getMonth()];
var date = d.getDate();
var year = d.getFullYear();
var hour = d.getHours();
var am_pm = "am"
if (hour > 12){
	hour = hour - 12;
	am_pm = "pm"
}
else if (hour == 0){
	hour = 12;
}

var minute = d.getMinutes();
if (minute < 10){
	minute = "0" + String(minute);
}

datetime += String(day)+", "+String(month)+" "+String(date)
+", "+String(year)+" | "+String(hour)+":"+String(minute)
+" "+String(am_pm);
document.getElementById("datetime").innerHTML = datetime;